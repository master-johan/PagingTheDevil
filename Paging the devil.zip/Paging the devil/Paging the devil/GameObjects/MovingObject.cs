﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Paging_the_devil
{
    class MovingObject : GameObject
    {
        public MovingObject(Texture2D tex, Vector2 pos, Rectangle rect) : base(tex, pos, rect)
        {

        }

        public override void Update()
        {

        }

        public override void Draw(SpriteBatch spriteBatch)
        {

        }
    }
}
